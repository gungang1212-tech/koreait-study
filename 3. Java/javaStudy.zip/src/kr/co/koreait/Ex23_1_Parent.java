package kr.co.koreait;

public class Ex23_1_Parent {
	
	public void printHllo() {
		System.out.println("안녕하세요. 부모 클래스입니다.");
	}

}
