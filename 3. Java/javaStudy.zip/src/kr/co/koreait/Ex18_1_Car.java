package kr.co.koreait;

public class Ex18_1_Car {
	// 변수 선언
	int wheel;
	
	// 명시적 초기화
	int speed = 100;
}
