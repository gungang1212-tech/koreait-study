package kr.co.koreait;

public class Ex22_2_Animal {
	// eat 메서드
	//	- "먹는중" 출력
	public void eat() {
		System.out.println("먹는중");
	}
	
	// sleep 메서드
	//	- "자는중" 출력
	public void sleep() {
		System.out.println("자는중");
	}
	// makeSound 메서드
	//	- "동물이 소리를 냅니다." 출력
	public void makeSound() {
		System.out.println("동물이 소리를 냅니다.");
	}
}










