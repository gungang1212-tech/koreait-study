package kr.co.koreait;

public class Ex21_2_Person {
	String name;
	int age;
	
	Ex21_2_Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
}
