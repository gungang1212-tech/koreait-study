package kr.co.koreait;

public interface Ex24_2_Phone {
	// static final 생략되어 있음
	int MAX_BATTERY_CAPACITY = 100;
	
	public abstract void openingLogo();

	// abstract 생략되어 있음
	public void powerOn();
	public void powerOff();
}
