package kr.co.koreait;

public class Ex23_3_Computer {
	public void powerOn() {
		System.out.println("컴퓨터가 켜졌습니다.");
	}

	public void powerOff() {
		System.out.println("컴퓨터가 꺼졌습니다.");
	}

}
