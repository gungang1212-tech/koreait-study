package kr.co.koreait;

public class Ex23_1_Child extends Ex23_1_Parent {
	
	public void displayHello() {
		System.out.println("안녕하세요. 저는 자식 클래스입니다."); 
	}
	
}
