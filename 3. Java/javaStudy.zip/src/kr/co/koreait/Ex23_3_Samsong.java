package kr.co.koreait;

public class Ex23_3_Samsong extends Ex23_3_Computer {
	@Override
	public void powerOn() {
		System.out.println("삼송 컴퓨터가 켜졌습니다.");
	}

}
