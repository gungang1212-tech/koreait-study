package kr.co.koreait;

public class Ex22_2_Dog extends Ex22_2_Animal {
	@Override
	public void makeSound() {
		System.out.println("멍멍");
	}
}
