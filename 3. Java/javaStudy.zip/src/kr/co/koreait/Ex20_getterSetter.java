package kr.co.koreait;

public class Ex20_getterSetter {

	public static void main(String[] args) {
		Ex20_1_Person kim = new Ex20_1_Person();
		kim.setAge(-10);
		System.out.println(kim.getAge());
		
		System.out.println(kim.toString());
	}

}
