package kr.co.koreait;

public class Ex22_1_Samsong extends Ex22_1_Computer {
	@Override
	public void powerOn() {
		System.out.println("삼송 컴퓨터가 켜졌습니다.");
	} 
	
	@Override   
	public void powerOff() {
		System.out.println("삼송 컴퓨터가 꺼졌습니다.");
	}
} 
