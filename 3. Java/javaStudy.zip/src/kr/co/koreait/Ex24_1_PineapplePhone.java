package kr.co.koreait;

public class Ex24_1_PineapplePhone extends Ex24_1_Phone {
	@Override
	public void openingLogo() {
		System.out.println("@@@");
	}

}
