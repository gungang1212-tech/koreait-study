package kr.co.koreait;

public class Ex22_1_Computer {
	public void powerOn() {
		System.out.println("powerOn");
	}
	
	public void powerOff() {
		System.out.println("powerOff");
	}

}
