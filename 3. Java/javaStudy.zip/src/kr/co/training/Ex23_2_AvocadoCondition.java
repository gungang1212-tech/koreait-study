package kr.co.training;

public class Ex23_2_AvocadoCondition {
	// Ex23_2_AvocadoCondition 클래스를 생성하세요.
	//	- hasAvocado 메서드를 작성하세요.
	//		> 해당 메서드는 false를 반환합니다.
	public boolean hasAvocado() {
		return false;
	}
}
