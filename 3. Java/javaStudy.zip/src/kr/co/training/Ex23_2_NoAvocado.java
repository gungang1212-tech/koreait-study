package kr.co.training;

public class Ex23_2_NoAvocado extends Ex23_2_AvocadoCondition {
	// Ex23_2_NoAvocado 클래스를 생성하세요.
	//	- Ex23_2_AvocadoCondition 클래스를 상속 받습니다.
	//	- 부모의 기본 동작을 그대로 사용하기 때문에 오버라이딩을 하지 않습니다.
	
}
