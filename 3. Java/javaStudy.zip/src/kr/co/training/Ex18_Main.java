package kr.co.training;

public class Ex18_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
