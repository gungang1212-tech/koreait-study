package kr.co.training;

public class Ex21_3_Character {
	// walk 메서드
	//	- "케릭터가 한걸음 걷습니다" 출력
	
	// stop 메서드
	//	- "케릭터가 멈춥니다." 출력
	
	// attack 메서드
	//	- "주먹으로 공격합니다." 출력
	
	// skill 메서드
	//	- "공통 스킬을 사용합니다." 출력

}
