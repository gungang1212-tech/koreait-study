package kr.co.training;

public class Test {
	public int num1;
	
	int num2;
	
	private int num3;
}
