package kr.co.training;

public class Ex26_1_DulicateBookException extends RuntimeException {
	Ex26_1_DulicateBookException(String msg) {
		super(msg);
	}
}
