package kr.co.training;

public class Ex20_2_BookInfo {
	
	// 도서관에 남은 책의 수
	private int bookCount;
	
	// getter/setter
	public void setBookCount(int bookCount) {
		this.bookCount = bookCount;
	}
	
	public int getBookCount() {
		return bookCount;
	}

}
