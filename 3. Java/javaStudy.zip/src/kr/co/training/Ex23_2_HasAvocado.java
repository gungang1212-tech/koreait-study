package kr.co.training;

public class Ex23_2_HasAvocado extends Ex23_2_AvocadoCondition {
	// Ex23_2_HasAvocado 클래스를 생성하세요.
	//	- Ex23_2_AvocadoCondition 클래스를 상속 받습니다.
	//	- hasAvocado 메서드를 오버라이딩 하세요.
	//		> 해당 메서드는 true를 반환합니다.
	@Override
	public boolean hasAvocado() {
		return true;
	}
	
}
