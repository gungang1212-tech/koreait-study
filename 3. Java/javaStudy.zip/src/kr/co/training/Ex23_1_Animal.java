package kr.co.training;

public class Ex23_1_Animal {
	// cry 메서드를 가집니다.
	//	- 문자열 soundString 매개변수를 가집니다.
	//	- 매개변수로 전달받은 값을 출력
	public void cry(String soundString) {
		System.out.println(soundString);
	}
}
