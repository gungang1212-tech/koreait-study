export default function Child({name, count}){
    // 조건부 렌더링
    //  - 특정 조건이 해당할 경우에만 렌더링하는 방식(if문, 삼항연산자)

    // if(name == '짱구') {
    //     return (
    //         <>
    //             <p>이름은 짱구입니다.</p>
    //         </>
    //     )
    // }

    // return (
    //     <>
    //         <p>짱구가 아닙니다.</p>
    //     </>
    // )

    return (
        <>
            {/* 
                name이 짱구가 아니라면 '짱구가 아닙니다' 렌더링
                    -> 조건식이 true면 렌더링, false면 렌더링하지 않음
                    -> 렌더링할 요소는 1개여야 함 (2개 이상은 에러)
            */}
            {name !== '짱구' && <>
                                    <p>'짱구가 아닙니다.'</p>
                                    <p>asdasdasd</p>
                                </>}
                                
            {count === 1 && <p>count의 값은 1입니다.</p>}

            {countString}
        </>
    )

}