-- employees라는 데이터베이스 선택
use employees;

select emp_no, first_name from employees;
select emp_no, birth_date from employees;
select hire_date from employees;
select emp_no, from_date, to_date from dept_manager;
select * from departments;
select * from employees;

insert into employees 
values (1,
		'2000-01-01',
		'jaeseop',
		'kim',
		'M',
		now());



INSERT INTO departments
VALUES ("d010",
		"Korea IT Department");

 INSERT INTO employees 
 VALUES (2,
 		 "2002-01-01",
 		 "jaeseop",
 		 "kim",
 		 "M",
 		 now());
 
 INSERT INTO dept_emp
 VALUES (1,
 		 "d010",
 		 now(),
 		 "9999-01-01");	

SELECT * FROM departments;

UPDATE employees
SET first_name = '길동'
WHERE emp_no = 10001;

UPDATE employees
SET last_name = '홍',
	hire_date = now()
WHERE emp_no = 10001;

SELECT * FROM employees WHERE last_name = 'Erie';

UPDATE departments d 
SET dept_name = 'Tech Sales'
WHERE dept_no = 'd007';

SELECT * FROM departments;

UPDATE employees
SET birth_date = '1977-07-07'
WHERE last_name = 'Erie';

SELECT * FROM employees
WHERE last_name = 'Erie';

DELETE FROM employees 
WHERE emp_no = 10005;

SELECT * FROM employees;

DELETE FROM employees 
WHERE hire_date = '1993-05-12';

SELECT * FROM employees
WHERE hire_date = '1993-05-12';

# emp_no = 28847
DELETE FROM employees
WHERE emp_no = 28847;


CREATE TABLE test_member (
	member_id varchar(50) COMMENT '아이디',
	member_pwd varchar(255) COMMENT '비밀번호',
	member_name varchar(50) COMMENT '이름',
	member_age TINYINT COMMENT '나이',
	member_in_date datetime COMMENT '가입일'
);

DROP TABLE test_member;

CREATE TABLE FREE_BOARD (
	BOARD_NO INT COMMENT '게시판 번호',
	BOARD_TITLE VARCHAR(100) COMMENT '게시판 제목',
	BOARD_CONTENT TEXT COMMENT '게시판 내용',
	BOARD_DATE DATETIME COMMENT '게시판 작성일',
	BOARD_VIEWS INT COMMENT '게시판 조회수'
); 

INSERT INTO FREE_BOARD
VALUES(1, '제목입니다.', '내용', NOW(), 1);

SELECT * FROM FREE_BOARD;



CREATE TABLE test_employees (
    te_employee_id INT,
    te_first_name VARCHAR(50),
    te_last_name VARCHAR(50),
    te_salary INT,
    te_department VARCHAR(50)
);


-- 1. test_employees 테이블의 이름을 “STAFF"로 변경
ALTER TABLE test_employees RENAME TO staff;

-- 2. te_department 컬럼의 데이터 형식을 VARCHAR(100)으로 변경
ALTER TABLE staff MODIFY te_department varchar(100);

-- 3. te_last_name 컬럼의 이름을 "Surname"으로 변경
ALTER TABLE staff RENAME column te_last_name TO surname;

-- 4. te_first_name 컬럼 삭제
ALTER TABLE staff DROP COLUMN te_first_name;

-- 5. te_hire_date라는 DATETIME 데이터 형식의 새로운 컬럼을 추가
ALTER TABLE staff ADD COLUMN te_hire_date datetime;

-- 6. te_salary_check 라는 이름을 가진 UNIQUE 제약 조건을 추가
--     이 제약 조건은 "Salary" 컬럼에 적용
ALTER TABLE staff ADD CONSTRAINT te_salary_check UNIQUE(te_salary);


DROP TABLE ddl_alter;

-- free_board, staff, test_member
DROP TABLE free_board;
DROP TABLE staff;
DROP TABLE test_member;
